export default function handler(req, res) {
  res.status(200).json({
    version: "2.0",
    updateType: "silent",
    bundleUrl: "https://你的项目名.onrender.com/bundle.zip",
    updateDesc: "新增功能、优化性能、修复bug"
  });
}
