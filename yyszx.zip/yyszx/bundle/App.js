import { View, Text } from 'react-native';
export default function App() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>我的APP - 最新版</Text>
    </View>
  );
}
