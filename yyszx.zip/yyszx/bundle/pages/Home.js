import { View, Text } from 'react-native';
export default function Home() {
  return (
    <View>
      <Text>首页</Text>
    </View>
  );
}
