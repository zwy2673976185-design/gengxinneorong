import { View, Text } from 'react-native';
export default function Tools() {
  return (
    <View>
      <Text>工具页</Text>
    </View>
  );
}
